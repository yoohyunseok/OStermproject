# -*- coding: utf-8 -*-
import cv2
import numpy as np




recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('C:/Users/UserName/Desktop/term/OpenCV-Python-Series-master/OpenCV-Python-Series-master/src/recognizers/face-trainner.yml')
cascadePath = 'C:/Users/UserName/Desktop/term/haarcascade_frontalface_default.xml'
faceCascade = cv2.CascadeClassifier(cascadePath)

font = cv2.FONT_HERSHEY_COMPLEX
id = 0
v = 20

names = ['None','hyun seok','changmin','karina','sunoo']

cam = cv2.VideoCapture(0)
cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1980)
cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

minW = 0.1 * cam.get(cv2.CAP_PROP_FRAME_WIDTH)
minH = 0.1 * cam.get(cv2.CAP_PROP_FRAME_HEIGHT)

while True:
    ret, img = cam.read()
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor = 1.2,
        minNeighbors = 6,
        minSize = (int(minW), int(minH))
    )
    if len(faces):
        for(x,y,w,h) in faces:
            cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)
            id, confidence = recognizer.predict(gray[y:y+h, x:x+w])
        #recognizer.predict(src) : �� ���� (id�� Ȯ���� ��ȯ)
        #confidence�� 0�� �������� label�� ��ġ
        
            if confidence < 55:
                id = names[id]
                roi_gray = gray[y : y + h, x : x + w]
                roi_color = img[y : y + h, x : x + w]

                roi = cv2.resize(roi_color, (w // v, h // v))
                roi = cv2.resize(roi, (w, h), interpolation=cv2.INTER_AREA)
                img[y:y+h, x:x+w] = roi
            else:
                id = "unknown"
            
            confidence = "  {0}%".format(round(100-confidence))
        
            cv2.putText(img,str(id), (x+5,y-5),font,1,(255,255,255),2)
            cv2.putText(img,str(confidence),(x+5,y+h-5),font,1,(255,255,0),1)
            #cv2.putText(img, text, bottom-left corner, font, fontScale, color, thickness) : label�� �������� �̹����� ��Ʈ�� ����Ѵ�
        
        
    cv2.imshow('camera',img)
    if cv2.waitKey(1)>0: break
    
print("\n [INFO] Exiting Program")
cam.release()
cv2.destroyAllWindows()