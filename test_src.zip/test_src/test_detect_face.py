import cv2
import numpy as np

#분류기
faceCascade = cv2.CascadeClassifier('C:/Users/UserName/Desktop/term/haarcascade_frontalface_default.xml')

#카메라 세팅
capture = cv2.VideoCapture(0) #초기화, 카메라 번호 (0:내장, 1:외장)
capture.set(cv2.CAP_PROP_FRAME_WIDTH,1280) #3
capture.set(cv2.CAP_PROP_FRAME_HEIGHT,720) #4

#console
face_id = input('\n enter user id and press <return> ==>') #사용자 id 입력 받기
print("\n [INFO] Initializing face capture. Look the CAMERA and wait")

count = 0 #데이터로 저장할 얼굴의 수

#영상 처리 및 출력
while True:
    ret, frame = capture.read() #카메라 상태, 프레임
    #frame = cv2.flip(frame, -1) #상하반전 
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) #흑백으로
    faces = faceCascade.detectMultiScale(gray, 1.2, 6)
    #원본이미지,scaleFactor = 1.2 #검색 윈도우 확대 비율 1보다 커야함, minNeighbors #얼굴 사이 최소 간격(픽셀),minSize #얼굴 최소 크기. 이것보다 작으면 무시
    
    #얼굴에 대해 rectangle 출력
    if len(faces):
        for (x,y,w,h) in faces: #(x,y):얼굴의 좌상단 위치, (w,h):가로,세로
            cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2) #이미지,좌상단좌표, 우하단좌표, 색상, 선두께)
            count += 1
            cv2.imwrite("C:/Users/UserName/Desktop/term/test/test_db/data."+str(face_id)+'.'+str(count)+".jpg", gray[y:y+h, x:x+w])
        
    cv2.imshow('image',frame)
    
    #종료조건
    if cv2.waitKey(1)>0: break
    elif count>=100: break #100 face sample
    
capture.release() #메모리 해제
cv2.destroyAllWindows() #모든 윈도우 창 닫기
